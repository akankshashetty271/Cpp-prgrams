#include<iostream>

using namespace std;

int main()
{
    cout<<"Jay Ganesh from C++\n";  // printf("Jay Ganesh from C++\n");
    
    return 0;
}






















